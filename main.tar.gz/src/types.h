#ifndef MAIN_SRC_TYPES_H
#define MAIN_SRC_TYPES_H

#define BUFFER_ERROR (msg_t *) NULL
#include "../../main/src/buffer.h"
#include "../../main/src/msg.h"
#include "../../main/src/condvar.h"

#endif
